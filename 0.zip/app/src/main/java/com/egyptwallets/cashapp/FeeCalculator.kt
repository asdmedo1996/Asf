package com.egyptwallets.cashapp

object FeeCalculator {
    fun calculateAtmFee(amount: Double): Double {
        return maxOf(1.0, amount * 0.01)
    }

    fun calculateTransferFee(amount: Double): Double {
        return if (amount > 2000.0) minOf(15.0, amount * 0.005) else 1.0
    }

    fun calculateReverseAmount(targetNet: Double): Double {
        return targetNet / 0.99
    }
}
