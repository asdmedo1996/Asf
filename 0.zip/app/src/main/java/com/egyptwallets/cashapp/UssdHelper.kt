package com.egyptwallets.cashapp

import android.content.Context
import android.content.Intent
import android.net.Uri

object UssdHelper {
    fun generateUssdCode(network: WalletNetwork, phone: String, amount: Double): String {
        val amtInt = amount.toInt()
        return when (network) {
            WalletNetwork.VODAFONE -> "*9*7*$phone*$amtInt#"
            WalletNetwork.ORANGE -> "*115*1*$phone*$amtInt#"
            WalletNetwork.ETISALAT -> "*777*1*$phone*$amtInt#"
            WalletNetwork.WE -> "*322*1*$phone*$amtInt#"
            WalletNetwork.UNKNOWN -> "*9*7*$phone*$amtInt#"
        }
    }

    fun callUssd(context: Context, ussdCode: String) {
        val encodedHash = Uri.encode("#")
        val ussdUri = ussdCode.replace("#", encodedHash)
        val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$ussdUri")).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    }
}
