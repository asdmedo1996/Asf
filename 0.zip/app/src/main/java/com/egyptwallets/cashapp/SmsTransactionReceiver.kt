package com.egyptwallets.cashapp

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.util.Log

class SmsTransactionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Telephony.Sms.Intents.SMS_RECEIVED_ACTION) {
            val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
            for (sms in messages) {
                val sender = sms.displayOriginatingAddress ?: ""
                val body = sms.displayMessageBody ?: ""
                Log.d("WalletSms", "Message from $sender: $body")

                // Auto parse transaction confirmation
                if (sender.contains("Vodafone", true) || sender.contains("Orange", true) ||
                    sender.contains("Etisalat", true) || sender.contains("WE", true)) {
                    // Extract amount, operation ID, remaining balance
                    // In a production app, save to Room DB or trigger local notification
                }
            }
        }
    }
}
