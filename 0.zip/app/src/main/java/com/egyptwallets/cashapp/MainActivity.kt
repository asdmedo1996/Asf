package com.egyptwallets.cashapp

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var etPhone: EditText
    private lateinit var etAmount: EditText
    private lateinit var tvDetectedNetwork: TextView
    private lateinit var tvFeeSummary: TextView
    private lateinit var btnCallUssd: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        checkPermissions()
        initViews()
    }

    private fun checkPermissions() {
        val permissions = arrayOf(
            Manifest.permission.CALL_PHONE,
            Manifest.permission.RECEIVE_SMS,
            Manifest.permission.READ_SMS
        )
        val needed = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (needed.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, needed.toTypedArray(), 101)
        }
    }

    private fun initViews() {
        etPhone = findViewById(R.id.et_phone)
        etAmount = findViewById(R.id.et_amount)
        tvDetectedNetwork = findViewById(R.id.tv_network)
        tvFeeSummary = findViewById(R.id.tv_fee)
        btnCallUssd = findViewById(R.id.btn_call_ussd)

        btnCallUssd.setOnClickListener {
            val phone = etPhone.text.toString().trim()
            val amount = etAmount.text.toString().toDoubleOrNull() ?: 0.0

            if (phone.length < 11) {
                Toast.makeText(this, "يرجى كتابة رقم هاتف صحيح 11 رقم", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (amount <= 0.0) {
                Toast.makeText(this, "يرجى تحديد المبلغ", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val network = NetworkDetector.detect(phone)
            val ussd = UssdHelper.generateUssdCode(network, phone, amount)
            UssdHelper.callUssd(this, ussd)
        }
    }
}
